-- =========================================================
-- NOURA — Schéma Supabase
-- « L'élégance dans votre cuisine »
-- À exécuter dans Supabase : SQL Editor > New query
-- =========================================================

-- Extension nécessaire pour gen_random_uuid()
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- 1. TABLE categories
-- ---------------------------------------------------------
create table if not exists public.categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 2. TABLE products
-- ---------------------------------------------------------
create table if not exists public.products (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  description   text,
  price         numeric(10,2) not null check (price >= 0),
  stock         integer not null default 0 check (stock >= 0),
  category_id   uuid references public.categories(id) on delete set null,
  image_url     text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists products_category_idx on public.products(category_id);
create index if not exists products_active_idx on public.products(is_active);

-- ---------------------------------------------------------
-- 3. TABLE orders
-- ---------------------------------------------------------
create table if not exists public.orders (
  id                uuid primary key default gen_random_uuid(),
  customer_name     text not null,
  customer_phone    text not null,
  customer_address  text not null,
  customer_city     text,
  payment_method    text not null check (payment_method in ('cash','wave','orange_money')),
  status            text not null default 'en_attente'
                      check (status in ('en_attente','confirmee','en_livraison','livree','annulee')),
  total             numeric(10,2) not null default 0,
  notes             text,
  created_at        timestamptz not null default now()
);

create index if not exists orders_status_idx on public.orders(status);
create index if not exists orders_created_idx on public.orders(created_at desc);

-- ---------------------------------------------------------
-- 4. TABLE order_items
-- ---------------------------------------------------------
create table if not exists public.order_items (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references public.orders(id) on delete cascade,
  product_id    uuid references public.products(id) on delete set null,
  product_name  text not null,
  unit_price    numeric(10,2) not null,
  quantity      integer not null check (quantity > 0),
  subtotal      numeric(10,2) not null
);

create index if not exists order_items_order_idx on public.order_items(order_id);

-- ---------------------------------------------------------
-- 5. Trigger updated_at sur products
-- ---------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on public.products;
create trigger trg_products_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------
-- 6. Row Level Security
-- ---------------------------------------------------------
alter table public.categories  enable row level security;
alter table public.products    enable row level security;
alter table public.orders      enable row level security;
alter table public.order_items enable row level security;

-- CATEGORIES : lecture publique, écriture admin (utilisateur authentifié)
create policy "categories_public_read" on public.categories
  for select using (true);
create policy "categories_admin_write" on public.categories
  for insert with check (auth.role() = 'authenticated');
create policy "categories_admin_update" on public.categories
  for update using (auth.role() = 'authenticated');
create policy "categories_admin_delete" on public.categories
  for delete using (auth.role() = 'authenticated');

-- PRODUCTS : lecture publique des produits actifs, admin voit/gère tout
create policy "products_public_read" on public.products
  for select using (is_active = true or auth.role() = 'authenticated');
create policy "products_admin_insert" on public.products
  for insert with check (auth.role() = 'authenticated');
create policy "products_admin_update" on public.products
  for update using (auth.role() = 'authenticated');
create policy "products_admin_delete" on public.products
  for delete using (auth.role() = 'authenticated');

-- ORDERS : n'importe qui peut créer une commande (client non connecté),
-- seul l'admin peut lire / modifier / supprimer
create policy "orders_public_insert" on public.orders
  for insert with check (true);
create policy "orders_admin_read" on public.orders
  for select using (auth.role() = 'authenticated');
create policy "orders_admin_update" on public.orders
  for update using (auth.role() = 'authenticated');
create policy "orders_admin_delete" on public.orders
  for delete using (auth.role() = 'authenticated');

-- ORDER_ITEMS : idem
create policy "order_items_public_insert" on public.order_items
  for insert with check (true);
create policy "order_items_admin_read" on public.order_items
  for select using (auth.role() = 'authenticated');
create policy "order_items_admin_delete" on public.order_items
  for delete using (auth.role() = 'authenticated');

-- ---------------------------------------------------------
-- 7. Stockage des images produits (bucket public en lecture)
-- ---------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "product_images_public_read" on storage.objects
  for select using (bucket_id = 'product-images');
create policy "product_images_admin_insert" on storage.objects
  for insert with check (bucket_id = 'product-images' and auth.role() = 'authenticated');
create policy "product_images_admin_update" on storage.objects
  for update using (bucket_id = 'product-images' and auth.role() = 'authenticated');
create policy "product_images_admin_delete" on storage.objects
  for delete using (bucket_id = 'product-images' and auth.role() = 'authenticated');

-- ---------------------------------------------------------
-- 8. Données de démarrage (catégories + produits d'exemple)
-- ---------------------------------------------------------
insert into public.categories (name, slug) values
  ('Assiettes', 'assiettes'),
  ('Bols & Saladiers', 'bols-saladiers'),
  ('Verres & Carafes', 'verres-carafes'),
  ('Couverts', 'couverts'),
  ('Plats de service', 'plats-de-service')
on conflict (slug) do nothing;

insert into public.products (name, slug, description, price, stock, category_id, image_url, is_active)
select
  'Assiette plate Ivoire', 'assiette-plate-ivoire',
  'Assiette plate en porcelaine ivoire au liseré doré, parfaite pour une table élégante au quotidien.',
  6500, 40, c.id,
  'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=800',
  true
from public.categories c where c.slug = 'assiettes'
on conflict (slug) do nothing;

insert into public.products (name, slug, description, price, stock, category_id, image_url, is_active)
select
  'Saladier Terre Cuite', 'saladier-terre-cuite',
  'Saladier artisanal en grès émaillé, aux tons beige et terracotta, fait à la main.',
  9800, 25, c.id,
  'https://images.unsplash.com/photo-1584346133934-a3402b0dc75a?w=800',
  true
from public.categories c where c.slug = 'bols-saladiers'
on conflict (slug) do nothing;

insert into public.products (name, slug, description, price, stock, category_id, image_url, is_active)
select
  'Carafe Ambre', 'carafe-ambre',
  'Carafe en verre soufflé teinté ambre, contenance 1,2L, idéale pour l''eau et les jus.',
  12000, 15, c.id,
  'https://images.unsplash.com/photo-1602881825632-4a0e5c0f77a2?w=800',
  true
from public.categories c where c.slug = 'verres-carafes'
on conflict (slug) do nothing;
