// =========================================================
// NOURA — Protection des pages admin
// Redirige vers la connexion si aucune session valide
// =========================================================
import { supabase } from './supabase-config.js';

export async function requireAuth() {
  const { data } = await supabase.auth.getSession();
  if (!data.session) {
    window.location.href = 'login.html';
    return null;
  }
  return data.session;
}

supabase.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') {
    window.location.href = 'login.html';
  }
});
