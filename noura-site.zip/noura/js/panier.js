// =========================================================
// NOURA — Logique page Panier
// =========================================================
import { formatPrice } from './supabase-config.js';
import { getCart, updateQuantity, removeFromCart, getCartTotal } from './cart.js';
import { showToast } from './main.js';

const content = document.getElementById('cart-content');

function render() {
  const cart = getCart();

  if (cart.length === 0) {
    content.innerHTML = `
      <div class="empty-state">
        <h3>Votre panier est vide</h3>
        <p>Découvrez notre sélection et ajoutez vos pièces préférées.</p>
        <a href="boutique.html" class="btn btn-gold" style="margin-top:14px">Aller à la boutique</a>
      </div>
    `;
    return;
  }

  const rows = cart.map((item) => `
    <tr>
      <td>
        <div class="cart-item-info">
          <img src="${item.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=200'}" alt="${item.name}">
          <div>
            <div class="cart-item-name">${item.name}</div>
            <button class="cart-remove" data-remove="${item.id}">Retirer</button>
          </div>
        </div>
      </td>
      <td>${formatPrice(item.price)}</td>
      <td>
        <div class="qty-control">
          <button type="button" data-minus="${item.id}">−</button>
          <input type="number" min="1" max="${item.stock || 99}" value="${item.quantity}" data-qty="${item.id}">
          <button type="button" data-plus="${item.id}">+</button>
        </div>
      </td>
      <td>${formatPrice(item.price * item.quantity)}</td>
    </tr>
  `).join('');

  const total = getCartTotal();

  content.innerHTML = `
    <div class="cart-layout">
      <div>
        <table class="cart-table">
          <thead>
            <tr><th>Produit</th><th>Prix</th><th>Quantité</th><th>Sous-total</th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <aside class="cart-summary">
        <h3 style="margin-bottom:16px">Résumé de la commande</h3>
        <div class="summary-row"><span>Sous-total</span><span>${formatPrice(total)}</span></div>
        <div class="summary-row"><span>Livraison</span><span>Calculée à l'étape suivante</span></div>
        <div class="summary-row total"><span>Total</span><span>${formatPrice(total)}</span></div>
        <a href="commande.html" class="btn btn-gold btn-block" style="margin-top:18px">Passer la commande</a>
        <a href="boutique.html" class="link-more" style="display:block;text-align:center;margin-top:14px">← Continuer mes achats</a>
      </aside>
    </div>
  `;

  content.querySelectorAll('[data-remove]').forEach((btn) => {
    btn.addEventListener('click', () => {
      removeFromCart(btn.dataset.remove);
      showToast('Article retiré du panier');
      render();
    });
  });
  content.querySelectorAll('[data-minus]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = cart.find((i) => i.id === btn.dataset.minus);
      if (item) { updateQuantity(item.id, Math.max(1, item.quantity - 1)); render(); }
    });
  });
  content.querySelectorAll('[data-plus]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = cart.find((i) => i.id === btn.dataset.plus);
      if (item) { updateQuantity(item.id, item.quantity + 1); render(); }
    });
  });
  content.querySelectorAll('[data-qty]').forEach((input) => {
    input.addEventListener('change', () => {
      const value = Math.max(1, Number(input.value) || 1);
      updateQuantity(input.dataset.qty, value);
      render();
    });
  });
}

render();
