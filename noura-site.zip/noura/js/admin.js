// =========================================================
// NOURA — Logique du tableau de bord admin
// =========================================================
import { supabase, formatPrice, slugify, PRODUCT_IMAGES_BUCKET } from './supabase-config.js';
import { requireAuth } from './auth-guard.js';

const session = await requireAuth();
if (session) {
  document.getElementById('admin-email').textContent = session.user.email;
}

let categoriesCache = [];

// ---------------------------------------------------------
// Navigation entre vues
// ---------------------------------------------------------
document.querySelectorAll('.admin-nav-link[data-view]').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.admin-nav-link').forEach((l) => l.classList.remove('active'));
    document.querySelectorAll('.admin-view').forEach((v) => v.classList.remove('active'));
    link.classList.add('active');
    document.getElementById(link.dataset.view).classList.add('active');
  });
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  await supabase.auth.signOut();
  window.location.href = 'login.html';
});

function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('[data-close]').forEach((btn) => {
  btn.addEventListener('click', () => closeModal(btn.dataset.close));
});
document.querySelectorAll('.modal-overlay').forEach((overlay) => {
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });
});

// ---------------------------------------------------------
// Aperçu
// ---------------------------------------------------------
async function loadOverview() {
  const [{ count: productCount }, { count: categoryCount }, { count: orderCount }, { count: pendingCount }] = await Promise.all([
    supabase.from('products').select('*', { count: 'exact', head: true }),
    supabase.from('categories').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'en_attente'),
  ]);

  document.getElementById('stat-products').textContent = productCount ?? 0;
  document.getElementById('stat-categories').textContent = categoryCount ?? 0;
  document.getElementById('stat-orders').textContent = orderCount ?? 0;
  document.getElementById('stat-pending').textContent = pendingCount ?? 0;

  const { data: recent } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(6);

  const body = document.getElementById('overview-orders-body');
  if (!recent || recent.length === 0) {
    body.innerHTML = '<tr><td colspan="5">Aucune commande pour le moment.</td></tr>';
    return;
  }
  body.innerHTML = recent.map((o) => `
    <tr>
      <td>${o.customer_name}</td>
      <td>${formatPrice(o.total)}</td>
      <td>${paymentLabel(o.payment_method)}</td>
      <td><span class="status-pill status-${o.status}">${statusLabel(o.status)}</span></td>
      <td>${new Date(o.created_at).toLocaleDateString('fr-FR')}</td>
    </tr>
  `).join('');
}

function paymentLabel(method) {
  return { cash: 'Livraison', wave: 'Wave', orange_money: 'Orange Money' }[method] || method;
}
function statusLabel(status) {
  return {
    en_attente: 'En attente', confirmee: 'Confirmée', en_livraison: 'En livraison',
    livree: 'Livrée', annulee: 'Annulée',
  }[status] || status;
}

// ---------------------------------------------------------
// Catégories
// ---------------------------------------------------------
async function loadCategories() {
  const { data } = await supabase.from('categories').select('*').order('name');
  categoriesCache = data || [];

  const select = document.getElementById('product-category');
  select.innerHTML = '<option value="">— Aucune —</option>' +
    categoriesCache.map((c) => `<option value="${c.id}">${c.name}</option>`).join('');

  const body = document.getElementById('categories-body');
  if (categoriesCache.length === 0) {
    body.innerHTML = '<tr><td colspan="3">Aucune catégorie. Ajoutez-en une.</td></tr>';
    return;
  }
  body.innerHTML = categoriesCache.map((c) => `
    <tr>
      <td>${c.name}</td>
      <td>${c.slug}</td>
      <td class="row-actions">
        <button class="edit-btn" data-edit-cat="${c.id}">Modifier</button>
        <button class="delete-btn" data-delete-cat="${c.id}">Supprimer</button>
      </td>
    </tr>
  `).join('');

  body.querySelectorAll('[data-edit-cat]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cat = categoriesCache.find((c) => c.id === btn.dataset.editCat);
      document.getElementById('category-modal-title').textContent = 'Modifier la catégorie';
      document.getElementById('category-id').value = cat.id;
      document.getElementById('category-name').value = cat.name;
      document.getElementById('category-form-error').textContent = '';
      openModal('category-modal');
    });
  });
  body.querySelectorAll('[data-delete-cat]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (!confirm('Supprimer cette catégorie ? Les produits associés ne seront pas supprimés.')) return;
      const { error } = await supabase.from('categories').delete().eq('id', btn.dataset.deleteCat);
      if (error) { alert("Erreur : " + error.message); return; }
      loadCategories();
    });
  });
}

document.getElementById('add-category-btn').addEventListener('click', () => {
  document.getElementById('category-modal-title').textContent = 'Ajouter une catégorie';
  document.getElementById('category-id').value = '';
  document.getElementById('category-name').value = '';
  document.getElementById('category-form-error').textContent = '';
  openModal('category-modal');
});

document.getElementById('category-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('category-form-error');
  const id = document.getElementById('category-id').value;
  const name = document.getElementById('category-name').value.trim();
  if (!name) { errorEl.textContent = 'Le nom est requis.'; return; }

  const slug = slugify(name);
  const payload = { name, slug };

  const { error } = id
    ? await supabase.from('categories').update(payload).eq('id', id)
    : await supabase.from('categories').insert(payload);

  if (error) { errorEl.textContent = error.message; return; }
  closeModal('category-modal');
  loadCategories();
});

// ---------------------------------------------------------
// Produits
// ---------------------------------------------------------
let productsCache = [];

async function loadProducts() {
  const { data, error } = await supabase
    .from('products')
    .select('*, categories(name)')
    .order('created_at', { ascending: false });

  const body = document.getElementById('products-body');
  if (error) { body.innerHTML = `<tr><td colspan="7">Erreur : ${error.message}</td></tr>`; return; }
  productsCache = data || [];

  if (productsCache.length === 0) {
    body.innerHTML = '<tr><td colspan="7">Aucun produit. Ajoutez votre premier article.</td></tr>';
    return;
  }

  body.innerHTML = productsCache.map((p) => `
    <tr>
      <td><img src="${p.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=100'}" alt=""></td>
      <td>${p.name}</td>
      <td>${p.categories?.name || '—'}</td>
      <td>${formatPrice(p.price)}</td>
      <td>${p.stock}</td>
      <td>${p.is_active ? 'Oui' : 'Non'}</td>
      <td class="row-actions">
        <button class="edit-btn" data-edit-prod="${p.id}">Modifier</button>
        <button class="delete-btn" data-delete-prod="${p.id}">Supprimer</button>
      </td>
    </tr>
  `).join('');

  body.querySelectorAll('[data-edit-prod]').forEach((btn) => {
    btn.addEventListener('click', () => openProductModal(productsCache.find((p) => p.id === btn.dataset.editProd)));
  });
  body.querySelectorAll('[data-delete-prod]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (!confirm('Supprimer ce produit définitivement ?')) return;
      const { error } = await supabase.from('products').delete().eq('id', btn.dataset.deleteProd);
      if (error) { alert('Erreur : ' + error.message); return; }
      loadProducts();
      loadOverview();
    });
  });
}

function openProductModal(product = null) {
  document.getElementById('product-form-error').textContent = '';
  document.getElementById('product-form').reset();
  const preview = document.getElementById('product-image-preview');
  preview.style.display = 'none';

  if (product) {
    document.getElementById('product-modal-title').textContent = 'Modifier le produit';
    document.getElementById('product-id').value = product.id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-description').value = product.description || '';
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-stock').value = product.stock;
    document.getElementById('product-category').value = product.category_id || '';
    document.getElementById('product-active').checked = product.is_active;
    if (product.image_url) {
      preview.src = product.image_url;
      preview.style.display = 'block';
    }
  } else {
    document.getElementById('product-modal-title').textContent = 'Ajouter un produit';
    document.getElementById('product-id').value = '';
    document.getElementById('product-active').checked = true;
  }
  openModal('product-modal');
}

document.getElementById('add-product-btn').addEventListener('click', () => openProductModal());

async function uploadProductImage(file) {
  const ext = file.name.split('.').pop();
  const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await supabase.storage.from(PRODUCT_IMAGES_BUCKET).upload(path, file);
  if (error) throw error;
  const { data } = supabase.storage.from(PRODUCT_IMAGES_BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

document.getElementById('product-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('product-form-error');
  const submitBtn = document.getElementById('product-submit-btn');
  errorEl.textContent = '';

  const id = document.getElementById('product-id').value;
  const name = document.getElementById('product-name').value.trim();
  const description = document.getElementById('product-description').value.trim();
  const price = Number(document.getElementById('product-price').value);
  const stock = Number(document.getElementById('product-stock').value);
  const category_id = document.getElementById('product-category').value || null;
  const is_active = document.getElementById('product-active').checked;
  const file = document.getElementById('product-image').files[0];

  if (!name || price < 0 || stock < 0) {
    errorEl.textContent = 'Merci de vérifier les champs obligatoires.';
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Enregistrement…';

  try {
    let image_url;
    if (file) image_url = await uploadProductImage(file);

    const payload = {
      name, description, price, stock, category_id, is_active,
      slug: slugify(name) + '-' + Date.now().toString(36),
    };
    if (image_url) payload.image_url = image_url;

    if (id) {
      delete payload.slug; // ne pas régénérer le slug lors d'une modification
      const { error } = await supabase.from('products').update(payload).eq('id', id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from('products').insert(payload);
      if (error) throw error;
    }

    closeModal('product-modal');
    loadProducts();
    loadOverview();
  } catch (err) {
    errorEl.textContent = err.message || "Une erreur est survenue.";
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Enregistrer';
  }
});

// ---------------------------------------------------------
// Commandes
// ---------------------------------------------------------
async function loadOrders() {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false });

  const body = document.getElementById('orders-body');
  if (error) { body.innerHTML = `<tr><td colspan="7">Erreur : ${error.message}</td></tr>`; return; }

  if (!data || data.length === 0) {
    body.innerHTML = '<tr><td colspan="7">Aucune commande pour le moment.</td></tr>';
    return;
  }

  body.innerHTML = data.map((o) => `
    <tr>
      <td>${o.customer_name}</td>
      <td>${o.customer_phone}</td>
      <td>${formatPrice(o.total)}</td>
      <td>${paymentLabel(o.payment_method)}</td>
      <td>
        <select class="status-select" data-status="${o.id}">
          ${['en_attente','confirmee','en_livraison','livree','annulee'].map((s) =>
            `<option value="${s}" ${s === o.status ? 'selected' : ''}>${statusLabel(s)}</option>`).join('')}
        </select>
      </td>
      <td>${new Date(o.created_at).toLocaleDateString('fr-FR')}</td>
      <td class="row-actions">
        <button class="edit-btn" data-view-order="${o.id}">Détails</button>
      </td>
    </tr>
  `).join('');

  body.querySelectorAll('[data-status]').forEach((select) => {
    select.addEventListener('change', async () => {
      const { error } = await supabase.from('orders').update({ status: select.value }).eq('id', select.dataset.status);
      if (error) alert('Erreur : ' + error.message);
      loadOverview();
    });
  });

  body.querySelectorAll('[data-view-order]').forEach((btn) => {
    btn.addEventListener('click', () => showOrderDetail(btn.dataset.viewOrder, data.find((o) => o.id === btn.dataset.viewOrder)));
  });
}

async function showOrderDetail(orderId, order) {
  const { data: items } = await supabase.from('order_items').select('*').eq('order_id', orderId);

  document.getElementById('order-modal-body').innerHTML = `
    <p><strong>${order.customer_name}</strong> — ${order.customer_phone}</p>
    <p style="color:var(--ink-muted)">${order.customer_address}${order.customer_city ? ', ' + order.customer_city : ''}</p>
    ${order.notes ? `<p style="color:var(--ink-muted)">Note : ${order.notes}</p>` : ''}
    <p>Paiement : <strong>${paymentLabel(order.payment_method)}</strong> · Statut : <span class="status-pill status-${order.status}">${statusLabel(order.status)}</span></p>
    <ul class="order-detail-list">
      ${(items || []).map((it) => `<li><span>${it.product_name} × ${it.quantity}</span><span>${formatPrice(it.subtotal)}</span></li>`).join('')}
    </ul>
    <p style="text-align:right;font-weight:600">Total : ${formatPrice(order.total)}</p>
  `;
  openModal('order-modal');
}

// ---------------------------------------------------------
// Chargement initial
// ---------------------------------------------------------
loadOverview();
loadCategories().then(loadProducts);
loadOrders();
