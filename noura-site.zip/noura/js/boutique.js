// =========================================================
// NOURA — Logique page Boutique
// =========================================================
import { supabase, formatPrice } from './supabase-config.js';
import { addToCart } from './cart.js';
import { showToast } from './main.js';

const grid = document.getElementById('product-grid');
const catList = document.getElementById('category-filters');
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const sortSelect = document.getElementById('sort-select');
const resultCount = document.getElementById('result-count');

const params = new URLSearchParams(window.location.search);
let state = {
  category: params.get('categorie') || '',
  search: params.get('q') || '',
  sort: 'recent',
};

if (state.search) searchInput.value = state.search;

async function loadCategories() {
  const { data } = await supabase.from('categories').select('*').order('name');
  if (!data) return;
  data.forEach((cat) => {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.textContent = cat.name;
    btn.dataset.cat = cat.slug;
    if (cat.slug === state.category) btn.classList.add('active');
    btn.addEventListener('click', () => {
      state.category = cat.slug;
      document.querySelectorAll('#category-filters button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      loadProducts();
    });
    li.appendChild(btn);
    catList.appendChild(li);
  });

  catList.querySelector('[data-cat=""]').addEventListener('click', () => {
    state.category = '';
    document.querySelectorAll('#category-filters button').forEach((b) => b.classList.remove('active'));
    catList.querySelector('[data-cat=""]').classList.add('active');
    loadProducts();
  });
}

function productCard(product) {
  const outOfStock = product.stock <= 0;
  return `
    <div class="product-card">
      <a href="produit.html?id=${product.id}" class="product-thumb">
        ${outOfStock ? '<span class="product-stock-flag">Épuisé</span>' : ''}
        <img src="${product.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=500'}" alt="${product.name}" loading="lazy">
      </a>
      <div class="product-body">
        <span class="product-cat">${product.categories?.name || ''}</span>
        <h3 class="product-name"><a href="produit.html?id=${product.id}">${product.name}</a></h3>
        <span class="product-price">${formatPrice(product.price)}</span>
        <div class="product-actions">
          <a href="produit.html?id=${product.id}" class="btn btn-outline btn-sm">Voir</a>
          <button class="btn btn-gold btn-sm" data-add="${product.id}" ${outOfStock ? 'disabled' : ''}>Ajouter</button>
        </div>
      </div>
    </div>
  `;
}

async function loadProducts() {
  grid.innerHTML = '<div class="loading-row">Chargement des produits…</div>';
  resultCount.textContent = 'Chargement…';

  let query = supabase.from('products').select('*, categories!inner(name, slug)').eq('is_active', true);

  if (state.category) query = query.eq('categories.slug', state.category);
  if (state.search) query = query.ilike('name', `%${state.search}%`);

  switch (state.sort) {
    case 'price-asc': query = query.order('price', { ascending: true }); break;
    case 'price-desc': query = query.order('price', { ascending: false }); break;
    case 'name': query = query.order('name', { ascending: true }); break;
    default: query = query.order('created_at', { ascending: false });
  }

  const { data, error } = await query;

  if (error) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><h3>Erreur</h3><p>${error.message}</p></div>`;
    resultCount.textContent = '';
    return;
  }

  if (!data || data.length === 0) {
    grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1"><h3>Aucun produit trouvé</h3><p>Essayez une autre catégorie ou un autre mot-clé.</p></div>';
    resultCount.textContent = '0 produit';
    return;
  }

  resultCount.textContent = `${data.length} produit${data.length > 1 ? 's' : ''}`;
  grid.innerHTML = data.map(productCard).join('');

  grid.querySelectorAll('[data-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const product = data.find((p) => p.id === btn.dataset.add);
      if (product) {
        addToCart(product, 1);
        showToast(`${product.name} ajouté au panier`);
      }
    });
  });
}

searchBtn.addEventListener('click', () => {
  state.search = searchInput.value.trim();
  loadProducts();
});
searchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    state.search = searchInput.value.trim();
    loadProducts();
  }
});
sortSelect.addEventListener('change', () => {
  state.sort = sortSelect.value;
  loadProducts();
});

loadCategories();
loadProducts();
