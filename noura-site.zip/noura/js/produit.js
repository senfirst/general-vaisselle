// =========================================================
// NOURA — Logique fiche produit
// =========================================================
import { supabase, formatPrice } from './supabase-config.js';
import { addToCart } from './cart.js';
import { showToast } from './main.js';

const container = document.getElementById('product-container');
const crumb = document.getElementById('crumb-name');
const relatedSection = document.getElementById('related-section');
const relatedGrid = document.getElementById('related-grid');

const id = new URLSearchParams(window.location.search).get('id');

function stockNote(stock) {
  if (stock <= 0) return '<p class="stock-note out">Rupture de stock</p>';
  if (stock <= 5) return `<p class="stock-note low">Plus que ${stock} en stock</p>`;
  return `<p class="stock-note">En stock</p>`;
}

async function loadProduct() {
  if (!id) {
    container.innerHTML = '<div class="empty-state"><h3>Produit introuvable</h3><p>Aucun identifiant fourni.</p></div>';
    return;
  }

  const { data: product, error } = await supabase
    .from('products')
    .select('*, categories(name, slug)')
    .eq('id', id)
    .single();

  if (error || !product) {
    container.innerHTML = '<div class="empty-state"><h3>Produit introuvable</h3><p>Ce produit n\'existe plus ou a été retiré.</p></div>';
    return;
  }

  document.title = `${product.name} — NOURA`;
  crumb.textContent = product.name;

  container.innerHTML = `
    <div class="product-detail">
      <div class="product-detail-gallery">
        <img src="${product.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=800'}" alt="${product.name}">
      </div>
      <div class="product-detail-info">
        <span class="product-cat">${product.categories?.name || ''}</span>
        <h1>${product.name}</h1>
        <p class="product-detail-price">${formatPrice(product.price)}</p>
        <p class="product-detail-desc">${product.description || 'Aucune description disponible pour cette pièce.'}</p>
        ${stockNote(product.stock)}
        <div class="qty-row">
          <div class="qty-control">
            <button type="button" id="qty-minus" aria-label="Diminuer">−</button>
            <input type="number" id="qty-input" value="1" min="1" max="${Math.max(product.stock, 1)}">
            <button type="button" id="qty-plus" aria-label="Augmenter">+</button>
          </div>
          <button class="btn btn-gold" id="add-cart-btn" ${product.stock <= 0 ? 'disabled' : ''}>Ajouter au panier</button>
        </div>
        <a href="panier.html" class="link-more">Voir mon panier →</a>
      </div>
    </div>
  `;

  const qtyInput = document.getElementById('qty-input');
  document.getElementById('qty-minus').addEventListener('click', () => {
    qtyInput.value = Math.max(1, Number(qtyInput.value) - 1);
  });
  document.getElementById('qty-plus').addEventListener('click', () => {
    qtyInput.value = Math.min(product.stock || 99, Number(qtyInput.value) + 1);
  });
  document.getElementById('add-cart-btn').addEventListener('click', () => {
    const qty = Math.max(1, Number(qtyInput.value) || 1);
    addToCart(product, qty);
    showToast(`${product.name} ajouté au panier`);
  });

  if (product.category_id) loadRelated(product.category_id, product.id);
}

async function loadRelated(categoryId, excludeId) {
  const { data } = await supabase
    .from('products')
    .select('*, categories(name)')
    .eq('category_id', categoryId)
    .eq('is_active', true)
    .neq('id', excludeId)
    .limit(4);

  if (!data || data.length === 0) return;

  relatedSection.style.display = '';
  relatedGrid.innerHTML = data.map((p) => `
    <div class="product-card">
      <a href="produit.html?id=${p.id}" class="product-thumb">
        <img src="${p.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=500'}" alt="${p.name}" loading="lazy">
      </a>
      <div class="product-body">
        <span class="product-cat">${p.categories?.name || ''}</span>
        <h3 class="product-name"><a href="produit.html?id=${p.id}">${p.name}</a></h3>
        <span class="product-price">${formatPrice(p.price)}</span>
      </div>
    </div>
  `).join('');
}

loadProduct();
