// =========================================================
// NOURA — Logique page d'accueil
// =========================================================
import { supabase, formatPrice } from './supabase-config.js';
import { addToCart } from './cart.js';
import { showToast } from './main.js';

const catGrid = document.getElementById('home-categories');
const prodGrid = document.getElementById('home-products');

const CATEGORY_IMAGES = {
  'assiettes': 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=500',
  'bols-saladiers': 'https://images.unsplash.com/photo-1584346133934-a3402b0dc75a?w=500',
  'verres-carafes': 'https://images.unsplash.com/photo-1602881825632-4a0e5c0f77a2?w=500',
  'couverts': 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=500',
  'plats-de-service': 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500',
};

async function loadCategories() {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name')
    .limit(5);

  if (error || !data || data.length === 0) {
    catGrid.innerHTML = '<div class="empty-state" style="grid-column:1/-1"><h3>Aucune catégorie</h3><p>Ajoutez des catégories depuis l\'espace admin.</p></div>';
    return;
  }

  catGrid.innerHTML = data.map((cat) => `
    <a class="cat-card" href="boutique.html?categorie=${encodeURIComponent(cat.slug)}">
      <img src="${CATEGORY_IMAGES[cat.slug] || 'https://images.unsplash.com/photo-1584346133934-a3402b0dc75a?w=500'}" alt="${cat.name}" loading="lazy">
      <span>${cat.name}</span>
    </a>
  `).join('');
}

function productCard(product) {
  const outOfStock = product.stock <= 0;
  return `
    <div class="product-card">
      <a href="produit.html?id=${product.id}" class="product-thumb">
        ${outOfStock ? '<span class="product-stock-flag">Épuisé</span>' : ''}
        <img src="${product.image_url || 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=500'}" alt="${product.name}" loading="lazy">
      </a>
      <div class="product-body">
        <span class="product-cat">${product.categories?.name || ''}</span>
        <h3 class="product-name"><a href="produit.html?id=${product.id}">${product.name}</a></h3>
        <span class="product-price">${formatPrice(product.price)}</span>
        <div class="product-actions">
          <a href="produit.html?id=${product.id}" class="btn btn-outline btn-sm">Voir</a>
          <button class="btn btn-gold btn-sm" data-add="${product.id}" ${outOfStock ? 'disabled' : ''}>Ajouter</button>
        </div>
      </div>
    </div>
  `;
}

async function loadFeatured() {
  const { data, error } = await supabase
    .from('products')
    .select('*, categories(name)')
    .eq('is_active', true)
    .order('created_at', { ascending: false })
    .limit(8);

  if (error) {
    prodGrid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><h3>Erreur de chargement</h3><p>${error.message}</p></div>`;
    return;
  }
  if (!data || data.length === 0) {
    prodGrid.innerHTML = '<div class="empty-state" style="grid-column:1/-1"><h3>Aucun produit pour le moment</h3><p>Revenez bientôt, notre sélection arrive.</p></div>';
    return;
  }

  prodGrid.innerHTML = data.map(productCard).join('');

  prodGrid.querySelectorAll('[data-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const product = data.find((p) => p.id === btn.dataset.add);
      if (product) {
        addToCart(product, 1);
        showToast(`${product.name} ajouté au panier`);
      }
    });
  });
}

loadCategories();
loadFeatured();
