// =========================================================
// NOURA — Connexion admin (Supabase Auth)
// =========================================================
import { supabase } from './supabase-config.js';

const form = document.getElementById('login-form');
const errorEl = document.getElementById('login-error');
const btn = document.getElementById('login-btn');

// Si déjà connecté, rediriger directement vers le tableau de bord
supabase.auth.getSession().then(({ data }) => {
  if (data.session) window.location.href = 'dashboard.html';
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.textContent = '';
  btn.disabled = true;
  btn.textContent = 'Connexion…';

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    errorEl.textContent = 'Identifiants incorrects. Vérifiez votre e-mail et mot de passe.';
    btn.disabled = false;
    btn.textContent = 'Se connecter';
    return;
  }

  window.location.href = 'dashboard.html';
});
