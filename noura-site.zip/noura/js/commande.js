// =========================================================
// NOURA — Logique page Commande
// =========================================================
import { supabase, formatPrice } from './supabase-config.js';
import { getCart, getCartTotal, clearCart } from './cart.js';

const summary = document.getElementById('order-summary');
const form = document.getElementById('checkout-form');
const formError = document.getElementById('form-error');
const submitBtn = document.getElementById('submit-btn');
const formSection = document.getElementById('order-form-section');
const confirmSection = document.getElementById('confirmation-section');
const confirmText = document.getElementById('confirm-text');

const cart = getCart();

function renderSummary() {
  if (cart.length === 0) {
    summary.innerHTML = `
      <h3>Votre panier est vide</h3>
      <p style="color:var(--ink-muted)">Ajoutez des produits avant de passer commande.</p>
      <a href="boutique.html" class="btn btn-gold btn-block">Aller à la boutique</a>
    `;
    submitBtn.disabled = true;
    return;
  }

  const total = getCartTotal();
  const lines = cart.map((item) => `
    <div class="summary-row"><span>${item.name} × ${item.quantity}</span><span>${formatPrice(item.price * item.quantity)}</span></div>
  `).join('');

  summary.innerHTML = `
    <h3 style="margin-bottom:14px">Votre commande</h3>
    ${lines}
    <div class="summary-row total"><span>Total</span><span>${formatPrice(total)}</span></div>
  `;
}
renderSummary();

// Toggle payment option styling + instructions
document.querySelectorAll('input[name="payment"]').forEach((radio) => {
  radio.addEventListener('change', () => {
    document.querySelectorAll('.payment-option').forEach((el) => el.classList.remove('selected'));
    radio.closest('.payment-option').classList.add('selected');
    document.getElementById('wave-details').style.display = radio.value === 'wave' ? 'block' : 'none';
    document.getElementById('orange-details').style.display = radio.value === 'orange_money' ? 'block' : 'none';
  });
});
document.querySelector('input[name="payment"]:checked')?.closest('.payment-option')?.classList.add('selected');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  formError.textContent = '';

  if (cart.length === 0) return;

  const fullname = document.getElementById('fullname').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const address = document.getElementById('address').value.trim();
  const city = document.getElementById('city').value.trim();
  const notes = document.getElementById('notes').value.trim();
  const payment = document.querySelector('input[name="payment"]:checked').value;

  if (!fullname || !phone || !address) {
    formError.textContent = 'Merci de renseigner votre nom, téléphone et adresse.';
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Envoi en cours…';

  const total = getCartTotal();

  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({
      customer_name: fullname,
      customer_phone: phone,
      customer_address: address,
      customer_city: city || null,
      payment_method: payment,
      total,
      notes: notes || null,
    })
    .select()
    .single();

  if (orderError || !order) {
    formError.textContent = "Une erreur est survenue lors de l'enregistrement de votre commande. Merci de réessayer.";
    submitBtn.disabled = false;
    submitBtn.textContent = 'Confirmer la commande';
    console.error(orderError);
    return;
  }

  const items = cart.map((item) => ({
    order_id: order.id,
    product_id: item.id,
    product_name: item.name,
    unit_price: item.price,
    quantity: item.quantity,
    subtotal: item.price * item.quantity,
  }));

  const { error: itemsError } = await supabase.from('order_items').insert(items);

  if (itemsError) {
    formError.textContent = "Commande créée mais un problème est survenu avec le détail des articles. Contactez-nous avec votre numéro de commande : " + order.id;
    console.error(itemsError);
  }

  clearCart();
  formSection.style.display = 'none';
  confirmSection.style.display = 'block';

  const paymentLabel = { cash: 'à la livraison', wave: 'via Wave', orange_money: 'via Orange Money' }[payment];
  confirmText.textContent = `Votre commande n°${order.id.slice(0, 8).toUpperCase()} a bien été enregistrée. Vous paierez ${paymentLabel}. Nous vous contacterons au ${phone} pour la livraison.`;
});
