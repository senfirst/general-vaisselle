// =========================================================
// NOURA — Configuration Supabase
// Remplacez les deux valeurs ci-dessous par celles de votre
// projet Supabase : Project Settings > API
// =========================================================
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

export const SUPABASE_URL = 'https://VOTRE-PROJET.supabase.co';
export const SUPABASE_ANON_KEY = 'VOTRE_CLE_ANON_PUBLIQUE';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Nom du bucket de stockage des images produits
export const PRODUCT_IMAGES_BUCKET = 'product-images';

// Format un nombre en Francs CFA
export function formatPrice(value) {
  const n = Number(value) || 0;
  return n.toLocaleString('fr-FR').replace(/,/g, ' ') + ' FCFA';
}

// Génère un slug simple à partir d'un nom
export function slugify(text) {
  return text
    .toString()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}
