# NOURA — Boutique en ligne de vaisselle

« L'élégance dans votre cuisine »

Site statique (HTML / CSS / JavaScript) connecté à **Supabase** pour la base de données, l'authentification admin et le stockage des images produits.

## 1. Créer le projet Supabase

1. Allez sur [supabase.com](https://supabase.com) et créez un nouveau projet.
2. Dans **SQL Editor**, ouvrez une nouvelle requête, collez le contenu de `sql/schema.sql` et exécutez-le. Cela crée :
   - les tables `categories`, `products`, `orders`, `order_items`
   - les règles de sécurité (Row Level Security)
   - le bucket de stockage `product-images`
   - quelques catégories et produits de démonstration
3. Dans **Authentication > Users**, créez manuellement votre compte administrateur (email + mot de passe). Il n'y a pas d'inscription publique : seul ce compte pourra se connecter à l'espace admin.

## 2. Connecter le site à votre projet

Ouvrez `js/supabase-config.js` et remplacez :

```js
export const SUPABASE_URL = 'https://VOTRE-PROJET.supabase.co';
export const SUPABASE_ANON_KEY = 'VOTRE_CLE_ANON_PUBLIQUE';
```

par les valeurs trouvées dans **Project Settings > API** de votre projet Supabase (URL et clé `anon public`).

## 3. Lancer le site

Ce projet est 100% statique. Vous pouvez :
- l'ouvrir directement (`index.html`) avec un serveur local (ex. l'extension "Live Server" de VS Code, ou `npx serve`), car les modules JavaScript (`type="module"`) nécessitent un serveur HTTP (pas `file://`) ;
- ou le déployer sur Netlify, Vercel, GitHub Pages, ou tout hébergement statique.

## 4. Structure du projet

```
index.html          Accueil
boutique.html        Boutique (catégories, recherche, produits)
produit.html          Fiche produit
panier.html          Panier
commande.html        Commande + choix du paiement
admin/login.html      Connexion admin
admin/dashboard.html  Gestion produits / catégories / commandes
css/style.css        Style du site public
css/admin.css        Style de l'espace admin
js/                  Logique JavaScript (Supabase, panier, pages)
sql/schema.sql        Script SQL Supabase complet
assets/logo.svg      Logo NOURA
```

## 5. Paiement

Le paiement à la livraison est enregistré tel quel. Pour Wave et Orange Money, le client est invité à effectuer un transfert manuel vers les numéros indiqués dans `commande.html` (à personnaliser) ; la commande est marquée « en attente » jusqu'à confirmation du paiement par l'admin, qui peut alors changer son statut dans le tableau de bord.

## 6. Sécurité

- Les visiteurs peuvent uniquement **lire** les catégories/produits actifs et **créer** des commandes.
- Seul un utilisateur authentifié (l'admin) peut créer/modifier/supprimer des produits, catégories, consulter les commandes et changer leur statut, et téléverser des images.
- Toutes ces règles sont appliquées côté base de données via Row Level Security (RLS), pas seulement côté interface.
